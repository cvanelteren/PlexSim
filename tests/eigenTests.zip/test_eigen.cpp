#include <iostream>
#include <time.h>
#include <Eigen/Dense>
#include <Eigen/Core>
using namespace std;
using namespace Eigen;

void test_init(){

    VectorXi sizes(4); sizes << 10, 100, 1000, 10000;
    VectorXd* vec = new VectorXd();
    clock_t start;
    cout << "Testing initializations" << endl;
    for (int i = 0 ; i < sizes.rows(); ++i){
        cout << "Testing " << sizes(i) << endl;
        start  = clock();
        *vec = VectorXd::Random(sizes(i));
        start  = clock() - start;
        cout << start / double (CLOCKS_PER_SEC) << endl;
    }
    return ;
}


void test_dot(){
    VectorXi sizes(4); sizes << 10, 100, 1000, 10000;
    VectorXd* a = new VectorXd();
    VectorXd* b = new VectorXd(); 
    VectorXd* c = new VectorXd(); 
    clock_t start;
    cout << "Testing dot" << endl;
    for (int i = 0 ; i < sizes.rows() ; ++ i ){
        *a = VectorXd::Random(sizes(i));
        *b = VectorXd::Random(sizes(i));

        start = clock();
        *c = (*a) * (*b);
        start = clock() - start;
        cout << start / double(CLOCKS_PER_SEC) << endl;
    }
    return ;
}

void test_init_mat(){
    VectorXi sizes(4); sizes << 10, 100, 1000, 10000;

    MatrixXd*a = new MatrixXd();
    clock_t start;
    cout << "Testing init mat" << endl;
    for (int i = 0; i < sizes.rows() ; ++i){
        start = clock();
        *a = MatrixXd::Random(sizes(i), sizes(i));
        start = clock() - start;

        cout << "size " << sizes(i) << " " << start / double(CLOCKS_PER_SEC) << endl;
    }
    return ;
}
void test_dot_mat(){
    VectorXi sizes(4); sizes << 10, 100, 1000, 10000;
    MatrixXd* a = new MatrixXd();
    MatrixXd* b = new MatrixXd();
    MatrixXd* c = new MatrixXd();

    clock_t start;
    cout << "Testing dot matrix" << endl;
    for (int i = 0 ; i < sizes.rows() ; ++ i){
        *a = MatrixXd::Random(sizes(i), sizes(i));
        *b = MatrixXd::Random(sizes(i), sizes(i));
        start = clock();
        *c = (*a) * (*b);
        start = clock() - start;

        cout << "size " << sizes(i) << " " << start / double(CLOCKS_PER_SEC) << endl;
    }
    return ;
}

int main(){
    // test_init();
    // test_dot();
    test_init_mat();
    test_dot_mat();
    return 0;
}
