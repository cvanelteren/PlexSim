.. Plexsim documentation master file, created by
   sphinx-quickstart on Tue Mar 30 21:54:02 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Plexsim's documentation!
===================================

Please note that the documentation is a work in progress and is as of yet not complete. Contributions are welcome |:wink:|!

.. image:: ./figures/new_banner.gif

.. autosummary::
   :toctree: _modules

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   quickstart
   glossary
   modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
