
g++ -O3 -I/usr/include -fopenmp -march=native test_xtensor.cpp -o tensor -lcblas
