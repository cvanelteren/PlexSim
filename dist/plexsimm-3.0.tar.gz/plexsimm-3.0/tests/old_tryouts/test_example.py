# from example import *
# import networkx as nx

# g = nx.path_graph(3)
# m = Potts(g)
# print(m.simulate(10).shape)
# print(m.sampleNodes(10))


# mm = Model(g)
# print(mm.sampleNodes(10))
